# Lubang Suara – Remotion 3D

1. `npm install`
2. `npm run dev`      → preview di Remotion Studio
3. `npm run build`    → render vertikal 1080x1920 ke out/lubang-suara.mp4
4. `npm run build:wide` → render horizontal 1920x1080

Durasi video dihitung otomatis dari public/narasi.mp3 (138,27 dtk = 4148 frame @30fps).
Ganti audio: timpa public/narasi.mp3, durasi menyesuaikan sendiri.
