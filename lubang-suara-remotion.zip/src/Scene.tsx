import React, {useLayoutEffect, useMemo, useRef} from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useAudioData, visualizeAudio} from '@remotion/media-utils';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';

export type Props = {audioFile: string; title: string};

// ---------- Konstanta sumur ----------
const RADIUS = 4;
const LAYER_H = 1.2;
const LAYERS = 80;
const PER_RING = 14;
const DEPTH = LAYERS * LAYER_H; // ~96 unit

// RNG deterministik (wajib: render harus identik di tiap frame)
const rand = (seed: number) => {
  const x = Math.sin(seed * 12.9898) * 43758.5453;
  return x - Math.floor(x);
};

// ---------- Batu sumur (instanced) ----------
const Stones: React.FC<{pulse: number; progress: number}> = ({pulse, progress}) => {
  const ref = useRef<THREE.InstancedMesh>(null);
  const count = LAYERS * PER_RING;

  useLayoutEffect(() => {
    const mesh = ref.current;
    if (!mesh) return;
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const e = new THREE.Euler();
    const color = new THREE.Color();
    let i = 0;
    for (let l = 0; l < LAYERS; l++) {
      for (let k = 0; k < PER_RING; k++) {
        const s = l * 100 + k;
        const ang = (k / PER_RING) * Math.PI * 2 + (l % 2) * (Math.PI / PER_RING) + (rand(s) - 0.5) * 0.06;
        const r = RADIUS + (rand(s + 1) - 0.5) * 0.45;
        const y = -l * LAYER_H + (rand(s + 2) - 0.5) * 0.1;
        const w = 1.55 + rand(s + 3) * 0.35;
        const h = LAYER_H * (0.82 + rand(s + 4) * 0.15);
        const t = 0.8 + rand(s + 5) * 0.5;
        e.set((rand(s + 6) - 0.5) * 0.08, -ang + Math.PI / 2, (rand(s + 7) - 0.5) * 0.06);
        q.setFromEuler(e);
        m.compose(
          new THREE.Vector3(Math.cos(ang) * r, y, Math.sin(ang) * r),
          q,
          new THREE.Vector3(w, h, t),
        );
        mesh.setMatrixAt(i, m);
        // lumut: makin dalam makin gelap & kehijauan
        const g = 0.16 + rand(s + 8) * 0.12;
        color.setRGB(g * 0.9, g * (1.0 + rand(s + 9) * 0.25), g * 0.85);
        mesh.setColorAt(i, color);
        i++;
      }
    }
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }, []);

  return (
    <instancedMesh ref={ref} args={[undefined, undefined, count]}>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial
        roughness={0.95}
        metalness={0.05}
        emissive={new THREE.Color('#5a0a0a')}
        emissiveIntensity={pulse * (0.15 + progress * 0.9)}
      />
    </instancedMesh>
  );
};

// ---------- Debu melayang ----------
const Dust: React.FC<{frame: number}> = ({frame}) => {
  const geo = useMemo(() => {
    const n = 700;
    const pos = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const a = rand(i) * Math.PI * 2;
      const r = Math.sqrt(rand(i + 1000)) * (RADIUS - 0.6);
      pos[i * 3] = Math.cos(a) * r;
      pos[i * 3 + 1] = -rand(i + 2000) * DEPTH;
      pos[i * 3 + 2] = Math.sin(a) * r;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    return g;
  }, []);

  return (
    <points geometry={geo} rotation={[0, frame * 0.002, 0]} position={[0, Math.sin(frame * 0.02) * 0.3, 0]}>
      <pointsMaterial color="#b9a58a" size={0.05} transparent opacity={0.55} sizeAttenuation depthWrite={false} />
    </points>
  );
};

// ---------- Kamera: turun perlahan ke dasar sumur ----------
const Rig: React.FC<{y: number; frame: number; shake: number}> = ({y, frame, shake}) => {
  const {camera} = useThree();
  const sx = Math.sin(frame * 0.011) * 0.55 + (rand(frame) - 0.5) * shake;
  const sz = Math.cos(frame * 0.009) * 0.5 + (rand(frame + 500) - 0.5) * shake;
  const roll = Math.sin(frame * 0.006) * 0.12;
  camera.position.set(sx, y, sz + 0.8);
  camera.up.set(Math.sin(roll), Math.cos(roll), 0);
  camera.lookAt(sx * 0.3, y - 7, -2.2 + sz * 0.3);
  camera.updateProjectionMatrix();
  return null;
};

// ---------- Adegan 3D ----------
const World: React.FC<{frame: number; progress: number; amp: number; durationInFrames: number}> = ({
  frame,
  progress,
  amp,
  durationInFrames,
}) => {
  const eased = Easing.inOut(Easing.cubic)(progress);
  const camY = interpolate(eased, [0, 1], [5, -DEPTH + 9]);
  const flicker = 0.75 + rand(Math.floor(frame / 2)) * 0.35 + amp * 1.8;
  const redIntensity = interpolate(progress, [0, 0.6, 1], [0.5, 4, 14]) * (1 + amp * 2.5);
  const shake = interpolate(progress, [0.7, 1], [0, 0.12], {extrapolateLeft: 'clamp'}) + amp * 0.12;

  return (
    <>
      <color attach="background" args={['#020203']} />
      <fog attach="fog" args={['#030304', 3, 26]} />
      <ambientLight intensity={0.08} />
      {/* lentera di tangan kamera */}
      <pointLight position={[0.6, camY + 0.5, 1.4]} color="#ffb070" intensity={55 * flicker} distance={22} decay={2} />
      {/* cahaya merah dari dasar */}
      <pointLight position={[0, -DEPTH + 2, 0]} color="#ff1a1a" intensity={redIntensity * 60} distance={70} decay={2} />

      <Rig y={camY} frame={frame} shake={shake} />
      <Stones pulse={amp} progress={progress} />
      <Dust frame={frame} />

      {/* dasar bercahaya */}
      <mesh position={[0, -DEPTH - 0.2, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[RADIUS + 0.5, 48]} />
        <meshBasicMaterial color={new THREE.Color().setRGB(0.9 + amp, 0.05, 0.05)} fog={false} />
      </mesh>
    </>
  );
};

// ---------- Komposisi utama ----------
export const LubangSuara: React.FC<Props> = ({audioFile, title}) => {
  const frame = useCurrentFrame();
  const {fps, width, height, durationInFrames} = useVideoConfig();
  const src = staticFile(audioFile);
  const audioData = useAudioData(src);

  let amp = 0;
  if (audioData) {
    const bins = visualizeAudio({fps, frame, audioData, numberOfSamples: 32});
    const low = bins.slice(0, 8);
    amp = Math.min(1, (low.reduce((a, b) => a + b, 0) / low.length) * 3.2);
  }

  const progress = frame / Math.max(1, durationInFrames - 1);

  const fadeIn = interpolate(frame, [0, fps * 1.2], [0, 1], {extrapolateRight: 'clamp'});
  const fadeOut = interpolate(frame, [durationInFrames - fps * 2, durationInFrames - 1], [1, 0], {
    extrapolateLeft: 'clamp',
  });

  const titleOpacity = interpolate(frame, [fps * 0.6, fps * 2, fps * 5, fps * 7], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const titleSpacing = interpolate(frame, [0, fps * 7], [0.25, 0.6]);

  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      <Audio src={src} />

      <AbsoluteFill style={{opacity: fadeIn * fadeOut}}>
        <ThreeCanvas width={width} height={height} camera={{fov: 62, near: 0.1, far: 120, position: [0, 5, 1]}}>
          <World frame={frame} progress={progress} amp={amp} durationInFrames={durationInFrames} />
        </ThreeCanvas>

        {/* vinyet */}
        <AbsoluteFill
          style={{
            background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 35%, rgba(0,0,0,0.85) 100%)',
            pointerEvents: 'none',
          }}
        />

        {/* kilatan merah mengikuti suara */}
        <AbsoluteFill
          style={{
            background: 'radial-gradient(ellipse at center, rgba(255,20,20,0.35), rgba(0,0,0,0) 60%)',
            opacity: amp * interpolate(progress, [0.4, 1], [0.1, 0.8], {extrapolateLeft: 'clamp'}),
            mixBlendMode: 'screen',
            pointerEvents: 'none',
          }}
        />

        {/* grain film */}
        <AbsoluteFill style={{opacity: 0.1, mixBlendMode: 'overlay', pointerEvents: 'none'}}>
          <svg width="100%" height="100%">
            <filter id="g">
              <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed={frame % 12} />
            </filter>
            <rect width="100%" height="100%" filter="url(#g)" />
          </svg>
        </AbsoluteFill>

        {/* judul */}
        <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', opacity: titleOpacity}}>
          <div
            style={{
              fontFamily: 'Georgia, "Times New Roman", serif',
              fontSize: Math.min(width, height) * 0.095,
              color: '#e8e0d4',
              letterSpacing: `${titleSpacing}em`,
              textAlign: 'center',
              textShadow: '0 0 30px rgba(255,30,30,0.6), 0 0 80px rgba(255,0,0,0.35)',
              paddingLeft: `${titleSpacing}em`,
            }}
          >
            {title}
          </div>
        </AbsoluteFill>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
