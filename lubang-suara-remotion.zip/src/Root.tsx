import {Composition, staticFile, CalculateMetadataFunction} from 'remotion';
import {getAudioDurationInSeconds} from '@remotion/media-utils';
import {LubangSuara, Props} from './Scene';

const FPS = 30;

// Durasi video otomatis = durasi audio (+ sedikit ekor hening agar fade out tidak terpotong)
const calculateMetadata: CalculateMetadataFunction<Props> = async ({props}) => {
  const seconds = await getAudioDurationInSeconds(staticFile(props.audioFile));
  return {durationInFrames: Math.ceil(seconds * FPS)};
};

const defaultProps: Props = {
  audioFile: 'narasi.mp3',
  title: 'LUBANG SUARA',
};

export const Root = () => (
  <>
    {/* Vertikal: TikTok / Reels / Shorts */}
    <Composition
      id="LubangSuara"
      component={LubangSuara}
      width={1080}
      height={1920}
      fps={FPS}
      durationInFrames={4148}
      defaultProps={defaultProps}
      calculateMetadata={calculateMetadata}
    />
    {/* Horizontal: YouTube */}
    <Composition
      id="LubangSuara-Wide"
      component={LubangSuara}
      width={1920}
      height={1080}
      fps={FPS}
      durationInFrames={4148}
      defaultProps={defaultProps}
      calculateMetadata={calculateMetadata}
    />
  </>
);
